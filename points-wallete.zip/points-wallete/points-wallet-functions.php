<?php 

// Display Points Price input fields for variations
function custom_add_points_price_input($loop, $variation_data, $variation) {
	echo '<div class="options_group">';
	
	woocommerce_wp_text_input(array(
			'id'          => '_points_price_' . $loop,
			'label'       => __('Points Price', 'custom-points-wallet'),
			'placeholder' => __('Enter Points Price', 'custom-points-wallet'),
			'desc_tip'    => 'true',
			'description' => __('Enter the Points price for this product.', 'custom-points-wallet'),
			'value'       => get_post_meta($variation->ID, '_points_price', true),
			'type'        => 'number',
			'custom_attributes' => array(
					'step' => 'any',
					'min'  => '0',
			),
	));
	
	echo '</div>';
}

add_action('woocommerce_variation_options_pricing', 'custom_add_points_price_input', 10, 3);

// Save Points Price for variations
function custom_save_points_price_input($variation_id, $loop) {
	$points_price_variation = isset($_POST['_points_price_' . $loop]) ? sanitize_text_field($_POST['_points_price_' . $loop]) : '';

	update_post_meta($variation_id, '_points_price', $points_price_variation);
}

add_action('woocommerce_save_product_variation', 'custom_save_points_price_input', 10, 2);

// Display Points Price input fields for all product types
function custom_add_points_price_input_all_types() {
	global $post;

	echo '<div class="options_group">';
	
	woocommerce_wp_text_input(array(
			'id'          => '_points_price',
			'label'       => __('Points Price', 'custom-points-wallet'),
			'placeholder' => __('Enter Points Price', 'custom-points-wallet'),
			'desc_tip'    => 'true',
			'description' => __('Enter the Points price for this product.', 'custom-points-wallet'),
			'value'       => get_post_meta($post->ID, '_points_price', true),
			'type'        => 'number',
			'custom_attributes' => array(
					'step' => 'any',
					'min'  => '0',
			),
	));

	echo '</div>';
}

add_action('woocommerce_product_options_pricing', 'custom_add_points_price_input_all_types');

// Save Points Price for all product types
function custom_save_points_price_input_all_types($post_id) {
	$points_price = isset($_POST['_points_price']) ? sanitize_text_field($_POST['_points_price']) : '';

	update_post_meta($post_id, '_points_price', $points_price);
}

add_action('woocommerce_process_product_meta', 'custom_save_points_price_input_all_types');



// Afficher la valeur du champ "Points Price" pour la première variation sur la page du produit
function custom_display_points_price_frontend_variations($price, $product) {
	$points_price = '';

	if ($product->is_type('variable')) {
			$variations = $product->get_available_variations();

			if (!empty($variations)) {
					$first_variation = reset($variations);
					$points_price = get_post_meta($first_variation['variation_id'], '_points_price', true);
			}
	} else {
			$points_price = get_post_meta($product->get_id(), '_points_price', true);
	}

	if (!empty($points_price)) {
			$price .= '<br/><span class="points-price">' . __('Points Price:', 'custom-points-wallet') . ' ' . wc_price($points_price) . '</span>';
	}

	return $price;
}

add_filter('woocommerce_get_price_html', 'custom_display_points_price_frontend_variations', 10, 2);


function custom_add_points_options_page() {
	add_menu_page(
			'Gestion des Points',
			'Points',
			'manage_options',
			'custom-points-options',
			'custom_render_points_options_page',
			'dashicons-money', 
			30
	);
}

add_action('admin_menu', 'custom_add_points_options_page');

function display_points($amount) {

    $decimal_part = $amount % 100;

    $integer_part = ($amount - $decimal_part) / 100;

    $formatted_amount = number_format($integer_part + $decimal_part / 100, 2, '.', ',');

   return $formatted_amount;
}



// Function to render the options page
function custom_render_points_options_page() {
	if (!current_user_can('manage_options')) {
		wp_die(__('Vous n\'avez pas les autorisations nécessaires pour accéder à cette page.'));
	}

	if (isset($_POST['action']) && in_array($_POST['action'], array('add', 'remove','edit'))) {
		$user_id = absint($_POST['user_id']);
		$points = floatval($_POST['points']);

		if ($_POST['action'] === 'add') {
			$current_points = get_user_meta($user_id, 'points', true);
			update_user_meta($user_id, 'points', $current_points + $points);
		} elseif ($_POST['action'] === 'edit') {
			$current_points = get_user_meta($user_id, 'points', true);
			update_user_meta($user_id, 'points',$points);
		}elseif ($_POST['action'] === 'remove') {
			$current_points = floatval(get_user_meta($user_id, 'points', true));
			update_user_meta($user_id, 'points', $current_points - $points);
		}

		wp_redirect(admin_url('admin.php?page=custom-points-options'));
		exit;
	}

	$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : 'name';
	$order = isset($_GET['order']) ? $_GET['order'] : 'asc';

	$users_per_page = 20;
	$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
	$offset = ($current_page - 1) * $users_per_page;

	$search_term = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';

    $args = array(
        'number' => $users_per_page,
        'offset' => $offset,
        'orderby' => $orderby,
        'order' => $order,
        'search' => '*' . $search_term . '*', // Search by name or email
        'search_columns' => array('user_login', 'user_email'), // Specify columns to search
    );

	$users_query = new WP_User_Query($args);
	$total_users = $users_query->get_total();

	$users = $users_query->get_results();
// var_dump($users);
	?>

	<div class="wrap">
		<h2>Points Management</h2>
		<form method="post">
            <p>
                <label for="search">Search: </label>
                <input type="text" id="search" name="search" value="<?php echo esc_attr($search_term); ?>">
                <input type="submit" class="button" value="Search">
                <?php if (!empty($search_term)) : ?>
                    <!-- Display reset button if search term is not empty -->
                    <button type="button" class="button" onclick="window.location.href='<?php echo admin_url('admin.php?page=custom-points-options'); ?>'">Reset</button>
                <?php endif; ?>
            </p>
        </form>
		<table class="widefat">
			<thead>
				<tr>
					<th><a href="<?php 
          echo esc_url(admin_url('admin.php?page=custom-points-options&orderby=name&order=' . ($orderby === 'name' && $order === 'asc' ? 'desc' : 'asc'))) 
          ?>">Nom</a></th>
					<th><a href="<?php echo esc_url(admin_url('admin.php?page=custom-points-options&orderby=email&order=' . ($orderby === 'email' && $order === 'asc' ? 'desc' : 'asc'))) ?>">Email</a></th>
					<th>Date d'inscription</th>
					<th>Rôle</th>
					<th>Points</th>
					<th>Date d'expiration</th>
					<th>Actions</th>
				</tr>
			</thead>
			 <?php if (empty($users)) : ?>
            <p class="user-not-found">No users found. please search with Email or exact Username</p>
        <?php else : ?>
			<tbody>
				<?php foreach ($users as $user) : ?>
					<?php
					$user_id = $user->ID;
					$user_name = $user->display_name;
					$user_email = $user->user_email;
					$user_registered = date('Y-m-d H:i:s', strtotime($user->user_registered));
					$user_points = get_user_meta($user_id, 'points', true);
					$points = !empty($user_points) ? $user_points : '0';
					$expiration_date = get_user_meta($user_id, 'points_expiration_date', true);
					$user_roles = ucfirst($user->roles[0]);
					?>
					<tr>
						<td><?php echo esc_html($user_name); ?></td>
						<td><?php echo esc_html($user_email); ?></td>
						<td><?php echo esc_html($user_registered); ?></td>
						<td><?php echo esc_html($user_roles); ?></td>
						<td><?php echo display_points($points) ?></td>
						<td><?php echo esc_html($expiration_date); ?></td>
						<td class="control-btn">
							<button class="sbw-btn edit-points-btn"><span class="dashicons dashicons-edit"></span></button>
							<form method="post" style="display: none;" class="edit-points-form">
								<input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
								<input type="hidden" name="action" value="edit">
								<input type="number" name="points" value="<?php echo $points ?>" required>
								<input type="submit" class="sbw-btn " value="Update">
								<input type="submit" class="sbw-btn cancel-edit " value="Cancel">
							</form>
							
							<button class="sbw-btn add-points-btn"><span class="dashicons dashicons-plus"></span></button>
							<form method="post" style="display: none;" class="add-points-form">
								<input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
								<input type="hidden" name="action" value="add">
								<input type="number" name="points" placeholder="Enter Points" required>
								<input type="submit" class="sbw-btn " value="Add">
								<input type="submit" class="sbw-btn cancel-add " value="Cancel">
							</form>

							<button class="sbw-btn remove-points-btn"><span class="dashicons dashicons-minus"></span></button>
							<form method="post" style="display: none;" class="remove-points-form">
								<input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
								<input type="hidden" name="action" value="remove">
								<input type="number" name="points" placeholder="Enter Points" required>
								<input type="submit" class="sbw-btn" value="Remove">
								<input type="submit" class="sbw-btn cancel-remove " value="Cancel">
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
			 <?php endif; ?>
		</table>
		<?php
		$base_url = admin_url('admin.php?page=custom-points-options');
		?>
    <div class="agination_container">
    <?php
		echo paginate_links(array(
			'base' => $base_url . '%_%',
			'format' => '&paged=%#%',
			'current' => $current_page,
			'total' => ceil($total_users / $users_per_page),
		));
		?>
	</div>
	</div>
		<style>
		.sbw-btn{
			display: inline-block;
    text-decoration: none;
    font-size: 13px;
    line-height: 2.15384615;
    min-height: 30px;
    margin: 0;
    padding: 0 10px;
    cursor: pointer;
    border-width: 1px;
    border-style: solid;
    -webkit-appearance: none;
    border-radius: 3px;
    white-space: nowrap;
    box-sizing: border-box;
		}
  .add-points-btn {
    
    align-items: center ;
      display: inline-grid ;
    margin-right: 10px ;
      background: green ;
      border-color: green ;
  }
  .add-points-btn:hover{
    background: #08c308 ;
    border-color: #08c308 ;
  }
  .remove-points-btn {
    align-items: center ;
      display: inline-grid ;
    margin-right: 10px;
      background: #c40404 ;
      border-color: #c40404 ;
  }
  .remove-points-btn:hover{
    background: #f41e1e ;
    border-color: #f41e1e ;
  }
     td.control-btn .dashicons, .dashicons-before:before {
      
        color: aliceblue;
    }
      .agination_container {
        margin-top: 10px;
        background: #1d2327;
        width: fit-content;
        padding: 10px;
        color: cornsilk;
        font-family: monospace;
    }
    .agination_container a {
        font-size: 15px;
        font-weight: 400;
        color: aliceblue;
        text-decoration: none;
    }
    .agination_container .page-numbers.current {
        color: #FF9800;
        font-size: 17px;
        font-family: monospace;
    }
    p.user-not-found {
    background: #cd433b;
    color: white;
    padding: 10px;
    width: fit-content;
    font-size: 14px;
}
button.sbw-btn.edit-points-btn {
    align-items: center;
    display: inline-grid;
    margin-right: 10px;
    background: #FFC107;
    border-color: #ffc107;
}
button.sbw-btn.edit-points-btn:hover {

    background: #ffd34f;
    border-color: #ffd34f;
}
	</style>
	<?php
}
add_action('admin_footer', 'enqueue_custom_js');

function enqueue_custom_js() {
	?>
	<script>
	jQuery(document).ready(function ($) {
    // Toggle add-points-form when add-points-btn is clicked
    $('.add-points-btn').on('click', function (e) {
        e.preventDefault();
        var $td = $(this).closest('td');
        $td.find('.add-points-form').toggle();
        $td.find('.add-points-btn, .remove-points-btn, .edit-points-btn').hide();
    });

    // Toggle edit-points-form when edit-points-btn is clicked
    $('.edit-points-btn').on('click', function (e) {
        e.preventDefault();
        var $td = $(this).closest('td');
        $td.find('.edit-points-form').toggle();
        $td.find('.add-points-btn, .remove-points-btn, .edit-points-btn').hide();
    });

    // Toggle remove-points-form when remove-points-btn is clicked
    $('.remove-points-btn').on('click', function (e) {
        e.preventDefault();
        var $td = $(this).closest('td');
        $td.find('.remove-points-form').toggle();
        $td.find('.add-points-btn, .remove-points-btn, .edit-points-btn').hide();
    });

    // Handle cancel-add button click
    $('.cancel-add').on('click', function (e) {
        e.preventDefault();
        var $td = $(this).closest('td');
        $td.find('.add-points-btn, .remove-points-btn, .edit-points-btn').toggle();
        $td.find('.add-points-form').hide();
    });

    // Handle cancel-remove button click
    $('.cancel-remove').on('click', function (e) {
        e.preventDefault();
        var $td = $(this).closest('td');
        $td.find('.add-points-btn, .remove-points-btn, .edit-points-btn').toggle();
        $td.find('.remove-points-form').hide();
    });
});

	</script>
	<?php
}

add_action('admin_footer', 'enqueue_custom_js');




// Add new tab to user profile
function add_points_tab($user) {
	?>
	<h2>Points</h2>
	<table class="form-table">
			<tr>
					<th><label for="points">Points</label></th>
					<td>
							<?php
							$points = get_user_meta($user->ID, 'points', true);
							echo esc_html($points);
							?>
					</td>
			</tr>
	</table>
	<?php
}
add_action('show_user_profile', 'add_points_tab');
add_action('edit_user_profile', 'add_points_tab');

