<?php 
/**
 * Plugin Name: Points wallet
 * Description: Custom Plugin for Points.
 * Version: 1.3
 * Author: ViaCommunication
 * Depends: WooCommerce
 */

 
if (!defined('ABSPATH')) {
  exit; 
}
function enqueue_custom_scripts() {
	wp_enqueue_script('jquery');
}
function enqueue_admin_custom_css(){

  wp_enqueue_style( 'admin-custom', plugin_dir_url(__FILE__) . 'assets/css/admin.css', array('style'), '1.0', true);
}
add_action( 'admin_head', 'enqueue_admin_custom_css' );
add_action( 'admin_enqueue_scripts', 'enqueue_admin_custom_css' );
add_action('wp_enqueue_scripts', 'enqueue_custom_checkout_script');
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if (is_plugin_active('woocommerce/woocommerce.php')) {
  

function enqueue_custom_checkout_script() {
    if (is_checkout() && !is_wc_endpoint_url()) {
        // wp_enqueue_script('custom-checkout-script', plugin_dir_url(__FILE__) . 'assets/js/custom-checkout-script.js', array('jquery'), '1.0', true);
        wp_enqueue_style('custom-checkout-style', plugin_dir_url(__FILE__) . 'assets/css/style.css', array('style'), '1.0', true);
    }
}

add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');
require_once plugin_dir_path(__FILE__) . 'points-wallet-functions.php';


add_action('elementor/widgets/widgets_registered', function () {
  require_once plugin_dir_path(__FILE__) . 'points-elementor-points-widget.php';
});


require_once plugin_dir_path(__FILE__) . 'class-points-gateway.php';
require_once plugin_dir_path(__FILE__) . 'global-functions.php';
require_once plugin_dir_path(__FILE__) . 'points-dashboard.php';
//require_once plugin_dir_path(__FILE__) . 'templates/checkout/points-payment.php';

}
/**
 * Disable WooCommerce block styles (front-end).
 */
function via_disable_woocommerce_block_styles() {
  wp_dequeue_style( 'wc-blocks-style' );
}
add_action( 'wp_enqueue_scripts', 'via_disable_woocommerce_block_styles' );
