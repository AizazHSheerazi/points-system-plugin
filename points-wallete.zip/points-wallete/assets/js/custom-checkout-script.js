jQuery(document).ready(function ($) {
  // Initially hide other payment methods
  $('input[name="payment_method"]').not('.sunnbucks-radio').closest('li').hide();

  // Show/hide payment methods based on selection
  $('form.checkout').on('change', 'input[name="payment_method"]', function () {
      var selectedGateway = $(this).val();

      if (selectedGateway === 'points') {
          $('input[name="payment_method"]').not('.sunnbucks-radio').prop('checked', false);
      } else {
          $('input[name="payment_method"]').not('.sunnbucks-radio').prop('checked', true);
      }

      $('li.payment_method').hide();
      $('li.payment_method.' + selectedGateway).show();
  });
});
