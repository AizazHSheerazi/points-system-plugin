<?php 
function add_size_charts_meta_box($post_type) {
    if ($post_type == 'product') {
        add_meta_box(
            'size_charts',
            __('Size Charts', 'text-domain'),
            'size_charts_meta_box_content',
            'product',
            'normal',
            'default'
        );
    }
}
add_action('add_meta_boxes', 'add_size_charts_meta_box');

function size_charts_meta_box_content($post) {
    $woman_chart_size = get_post_meta($post->ID, '_woman_chart_size', true);
    $man_chart_size = get_post_meta($post->ID, '_man_chart_size', true);
    ?>
    <div class="chart_image_container">
       
        <?php 
            if (!empty($woman_chart_size)) {

                ?>
               <div class="chart_image_container_image">
            <img src="<?php echo esc_attr($woman_chart_size); ?>" width="100%"/>
        </div>
                <?php 
            }

            ?>

        <div class="chart_image_container_button">
            <label for="_woman_chart_size"><?php _e('Woman Chart Size Image', 'text-domain'); ?></label>
            <br />
            <input type="text" name="_woman_chart_size" id="_woman_chart_size" value="<?php echo esc_attr($woman_chart_size); ?>" />
            <button class="button" onclick="uploadMedia('_woman_chart_size'); return false;"><?php _e('Upload Woman Image', 'text-domain'); ?></button>
        </div>
    </div>

    <div class="chart_image_container">
            <?php 
            if (!empty($man_chart_size) ) {

                ?>
                 <div class="chart_image_container_image">
            <img src="<?php echo esc_attr($man_chart_size); ?>" width="100%" />
        </div>
                <?php 
            }

            ?>
       

        <div class="chart_image_container_button">
            <label for="_man_chart_size"><?php _e('Man Chart Size Image', 'text-domain'); ?></label>
            <br />
            <input type="text" name="_man_chart_size" id="_man_chart_size" value="<?php echo esc_attr($man_chart_size); ?>" />
            <button class="button" onclick="uploadMedia('_man_chart_size'); return false;"><?php _e('Upload Man Image', 'text-domain'); ?></button>
        </div>
    </div>

    <script>
        function uploadMedia(target) {
            var customUploader = wp.media({
                title: 'Choose Image',
                button: {
                    text: 'Choose Image'
                },
                multiple: false
            });

            customUploader.on('select', function() {
                var attachment = customUploader.state().get('selection').first().toJSON();
                jQuery('#' + target).val(attachment.url);
            });

            customUploader.open();
        }
    </script>
    <style>
        .chart-image-container {
    font-size: 17px;
    font-weight: 700;
}
        </style>
    <?php
}

function save_size_charts_meta_boxes($post_id) {
    $woman_chart_size = sanitize_text_field($_POST['_woman_chart_size']);
    $man_chart_size = sanitize_text_field($_POST['_man_chart_size']);

    update_post_meta($post_id, '_woman_chart_size', $woman_chart_size);
    update_post_meta($post_id, '_man_chart_size', $man_chart_size);
}
add_action('save_post', 'save_size_charts_meta_boxes');

add_action('woocommerce_product_meta_start', 'display_size_charts');

function display_size_charts() {
    global $product;

    if ($product && is_product()) {
        $woman_chart_size = get_post_meta($product->get_id(), '_woman_chart_size', true);
        $man_chart_size = get_post_meta($product->get_id(), '_man_chart_size', true);

        if (!empty($woman_chart_size)) {
            echo '<div class="chart-image-container">';
            echo '<a href="' . esc_url($woman_chart_size) . '" target="_blank">';
            echo 'Woman Size Shart.';
            echo '</a>';
            echo '</div>';
        }
        if (!empty($man_chart_size)) {
            echo '<div class="chart-image-container">';
            echo '<a href="' . esc_url($man_chart_size) . '" target="_blank">';
            echo 'Man Size Shart.';
            echo '</a>';
            echo '</div>';
        }

    }
}



function display_points_price_in_cart($item_data, $cart_item) {
    $product_id = $cart_item['product_id'];
    $variation_id = $cart_item['variation_id'];
    
    // Get Points price from variation or product
    $points_price = get_post_meta($variation_id > 0 ? $variation_id : $product_id, '_points_price', true);
   $points_price_logo = get_post_meta($product_id, '_points_price_for_logo', true);
   $sunbuck_logo_fee = 45.00;

    if (!empty($points_price)) {
        $item_data[] = array(
            'key'     => __('Points Price', 'your-text-domain'),
            'value'   => wc_price($points_price),
            'display' => '',
        );
    }
     if (!empty($points_price_logo)) {
        $item_data[] = array(
            'key'     => __('Points Logo Price', 'your-text-domain'),
            'value'   => $points_price_logo,
            'display' => '',
        );
    }
     if (!empty($sunbuck_logo_fee) && !empty($points_price_logo)) {
        $item_data[] = array(
            'key'     => __('Project start-up costs', 'your-text-domain'),
            'value'   => wc_price($sunbuck_logo_fee),
            'display' => '',
        );
    }

    return $item_data;
}


// CALCULATE SUB TOTAL SUNBUCK IN CART
function calculate_sunbuck_subtotal() {
    $sunbuck_subtotal = 0;
    $cartData_var = WC()->cart->get_cart();

    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
        $product = $cart_item['data'];
        $product_id = $cart_item['product_id'];
          $points_price_logo = get_post_meta($product_id, '_points_price_for_logo', true);
         $min_quantity_logo = get_post_meta($product_id, '_min_quantity_for_logo', true);
        $variation_id = $cart_item['variation_id'];

       
        $sunbuck_price = get_post_meta($variation_id > 0 ? $variation_id : $product_id, '_points_price', true);
        $quantity = $cart_item['quantity'];
        $total_price_points = $points_price_logo * $quantity;

         
        if (!empty($sunbuck_price) ) {
            if(!empty($points_price_logo)){
                  $product_total_sunbuck_price = $sunbuck_price * $quantity;
                  $logo_product_points = $points_price_logo * $quantity;
                  
                 $sunbuck_subtotal +=  $product_total_sunbuck_price +  $logo_product_points + 45;
              }else{
                 $sunbuck_subtotal += $sunbuck_price * $quantity;
            }
           
        }
 

    }

    return $sunbuck_subtotal;
}


function update_cart_item_prices($cart) {
    if (is_admin() && !defined('DOING_AJAX')) {
        return;
    }

    foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
        $product = $cart_item['data'];
        $quantity = $cart_item['quantity'];
        $price_logo_string = $cart_item['pricesssssss'][1];
        preg_match_all('!\d+!', $price_logo_string, $price_logo);
        $logo_price_total = floatval($price_logo[0][1]) * $quantity ;
        
        if ($product->is_type('variable')) {
            $variation_id = $cart_item['variation_id'];
            $variation = new WC_Product_Variation($variation_id);
            $regular_price = floatval($variation->get_price());
             
        } else {
            $regular_price = floatval($product->get_price());
        }

        // Calculate the new total price for the product including the logo price
        $new_total_price = $regular_price * $quantity;
        
 $min_quantity_for_logo = get_post_meta(get_the_ID(), '_min_quantity_for_logo', true);
  $points_price = get_post_meta(get_the_ID(), '_points_price', true);
//   if(!empty($min_quantity_for_logo) && !empty($points_price)){
      
  
        // Set the new total price for the product
        $product->set_price($new_total_price );
        $cart_item["optiontotal_woosppo"] = $new_total_price;
        $cart_item["line_subtotal"] = $new_total_price ;
        $cart_item["line_subtotal"] = $new_total_price ;
        $cart_item["line_total"] = floatval($new_total_price);
        //  echo "<pre>";
    //  var_dump( $new_total_price);
        //  echo "</pre>";
//   }
    }
}

add_action('woocommerce_before_calculate_totals', 'update_cart_item_prices', 1000, 1);


// Changing Cart Sub total
function woocommerce_cart_subtotal(  $cart_subtotal ){
    global  $line_subtotal;
    $line_subtotal = 0;
  
    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
        $listt = $cart_item['list-cart-type'];      
        $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
        $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );
        if ( $_product && $_product->exists() && $listt == $pur_mode && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
            $line_subtotal += $cart_item['line_total'];                 
        }
    }   
    $cart_subtotal = $line_subtotal;
    return $cart_subtotal;
}

add_filter( 'woocommerce_cart_subtotal', 'woocommerce_cart_subtotal', 99, 3 );




// Hook into the cart item data filter
add_filter('woocommerce_get_item_data', 'display_points_price_in_cart', 10, 2);


add_action('woocommerce_cart_totals_before_order_total', 'display_sunbuck_subtotal');

function display_sunbuck_subtotal() {
    $sunbuck_subtotal = calculate_sunbuck_subtotal();

    if ($sunbuck_subtotal > 0) {
        ?>
        <tr class="cart-subtotal">
            <th><?php esc_html_e('Project start-up', 'your-text-domain'); ?></th>
            <td data-title="<?php esc_attr_e('Project start-up', 'your-text-domain'); ?>">$45.00</td>
        </tr>
        <tr class="cart-subtotal">
            <th><?php esc_html_e('Sunbuck Subtotal', 'your-text-domain'); ?></th>
            <td data-title="<?php esc_attr_e('Sunbuck Subtotal', 'your-text-domain'); ?>"><?php echo $sunbuck_subtotal; ?></td>
        </tr>
        
        <?php
    }
}
add_action('woocommerce_review_order_after_order_total', 'display_points_order_total');
function display_points_order_total() {
    $points_order_total = calculate_sunbuck_subtotal();

    if (!empty($points_order_total)) {
        ?>
        <tr class="order-total-points">
            <th><?php esc_html_e('Order Total (in Points)', 'your-text-domain'); ?></th>
            <td><?php echo wc_price($points_order_total, array('currency' => 'Points')); ?></td>
        </tr>
        <?php
    }
}


add_filter('woocommerce_gateway_title', 'add_user_points_amount', 10, 2);

function add_user_points_amount($title, $payment_id) {
    if ('points_payment_gateway' === $payment_id) {
        $user_id = get_current_user_id();
        $user_points = get_user_meta($user_id, 'points', true);

        // Add user's Sunbuck amount after the title
        $title .= ' (' . __('Your Points: ', 'your-text-domain') . wc_price($user_points, array('currency' => 'Points')) . ')';
    }

    return $title;
}




// Update 01/02/24: Add support product option to subuck wallet

// Add custom fields to product edit screen in admin
function add_custom_fields_to_product_admin() {
    global $post;
     $points_price_for_logo = get_post_meta($post->ID, '_points_price_for_logo', true);
      $min_quantity_for_logo = get_post_meta($post->ID, '_min_quantity_for_logo', true);

    echo '<div class="options_group">';

    // Points price for the logo
    
    woocommerce_wp_text_input(
        array(
            'id'          => 'points_price_for_logo',
            'label'       => __('Points Price for Logo', 'textdomain'),
            'placeholder' => __('Enter Points price for the logo', 'textdomain'),
            'desc_tip'    => 'true',
            'description' => __('Enter the Points price for the logo.', 'textdomain'),
            'type'        => 'number',
            'custom_attributes' => array(
                'step' => '0.01',
            ),
             'value'       => $points_price_for_logo,
        )
    );

    // Minimum quantity for the logo
    woocommerce_wp_text_input(
        array(
            'id'          => 'min_quantity_for_logo',
            'label'       => __('Minimum Quantity for Logo', 'textdomain'),
            'placeholder' => __('Enter minimum quantity for the logo', 'textdomain'),
            'desc_tip'    => 'true',
            'description' => __('Enter the minimum quantity for the logo.', 'textdomain'),
            'type'        => 'number',
            'custom_attributes' => array(
                'step' => '1',
            ),
             'value'       => $min_quantity_for_logo,
        )
    );

    echo '</div>';
}

// Save custom fields when the product is saved
function save_custom_fields_for_product($post_id) {

    $points_price_for_logo = isset($_POST['points_price_for_logo']) ? wc_clean($_POST['points_price_for_logo']) : '';
    update_post_meta($post_id, '_points_price_for_logo', $points_price_for_logo);

   $min_quantity_for_logo_get = get_post_meta($post_id, '_min_quantity_for_logo', true);
    $min_quantity_for_logo = isset($_POST['min_quantity_for_logo']) ? wc_clean($_POST['min_quantity_for_logo']) : '';
    update_post_meta($post_id, '_min_quantity_for_logo', $min_quantity_for_logo);
}

// Hook the functions
add_action('woocommerce_product_options_general_product_data', 'add_custom_fields_to_product_admin');
add_action('woocommerce_process_product_meta', 'save_custom_fields_for_product');



function add_custom_js_for_total_price() {
  $points_price_for_logo = get_post_meta(get_the_ID(), '_points_price_for_logo', true);
  $min_quantity_for_logo = get_post_meta(get_the_ID(), '_min_quantity_for_logo', true);
  $points_price = get_post_meta(get_the_ID(), '_points_price', true);
  $points_order_total_with_logo = calculate_sunbuck_subtotal();

 if(!empty( $points_price_for_logo)){
     
 
      ?>
     <script>
    jQuery(document).ready(function ($) {
         $('.woosppo_main_parent_divv').hide();

        $('.input-text.qty').on('input', function () {
            var quantity = parseInt($(this).val());
            console.log('quantity ' +quantity);

            if (!isNaN(quantity) && quantity == <?php echo floatval($min_quantity_for_logo); ?> ) {
              
                $('.woosppo_main_parent_divv').show();
                  var targetElement = $('.plugify_expo_sty_div .woocommerce-Price-amount bdi');
            
             
                var currentHtml = targetElement.html();
            
               
                var newHtml = ' | <span>Points Price: <?php echo floatval($points_price_for_logo); ?></span>';
            
                
                targetElement.after(newHtml);
    
                    $('input[name="enable_logo_select_txt"]').change(function () {
                if ($(this).is(':checked')) {
                  
                    var pointsPriceLogo = <?php echo floatval($points_price_for_logo); ?>;
                    var totalPointsPrice = pointsPriceLogo * quantity;
                  
                    // var newH4ElementPointsPrice = '<h4 style="margin: unset;">' +
                    //     '<strong>Total Points Price:</strong><span><span id="complete_price_points" name="complete_price_points">' +
                    //     totalPointsPrice + '</span></span></h4>';
                    // $('.woosppo_main_parent_divv').after(newH4ElementPointsPrice);
                   
                }else{
                     var newH4ElementPointsPrice = "";
                    $('.woosppo_main_parent_divv').after(''); 
                }
            });
            }else {
              
                $('.woosppo_main_parent_divv').hide();
            }
        });

        
    });
</script>

      <?php
 }else{
      ?>
     <script>
    jQuery(document).ready(function ($) {
         $('.woosppo_main_parent_divv').hide();


        
    });
</script>

      <?php
 }
}

// Hook the function to wp_footer action to output the JavaScript in the footer
add_action('wp_footer', 'add_custom_js_for_total_price');



// Function to add new customer roles inheriting capabilities from the existing customer role
function add_custom_customer_roles() {
    $customer_role = get_role('customer');
    if ($customer_role) {
        $new_roles = array('authorized', 'branded', 'contractor','Sunspace Rep');
        foreach ($new_roles as $new_role) {
            $new_role_caps = $customer_role->capabilities;

            add_role(
                $new_role, 
                ucfirst($new_role),
                $new_role_caps
            );
        }
    }
}

// Hook the function to run when WordPress is initialized
add_action('init', 'add_custom_customer_roles');


// Function to update user meta depending on user role
function update_user_meta_based_on_role($user_id) {
    $user_roles = get_userdata($user_id)->roles;

    if (in_array('branded', $user_roles)) {
        update_user_meta($user_id, 'points_expiration_date', '∞'); // Update user meta with infinity symbol to indicate no expiration
    } elseif (in_array('authorized', $user_roles) || in_array('contractor', $user_roles)) {
        update_user_meta($user_id, 'points_expiration_date', date('Y-12-31')); // Update user meta with expiration date to December 31st of the current year
    } else {
        update_user_meta($user_id, 'points_expiration_date', date('Y-12-31', strtotime('+1 year'))); // Update user meta with expiration date to December 31st of next year
    }
}
// Function to set expiration date based on user role
function set_expiration_date($user_id) {
    $user_roles = get_userdata($user_id)->roles;

    $expiration_date = '';

    if (in_array('branded', $user_roles)) {
        $expiration_date = '∞'; 
    } elseif (in_array('authorized', $user_roles) || in_array('contractor', $user_roles)) {
        $expiration_date = date('Y-12-31'); 
    } else {
        $expiration_date = date('Y-12-31', strtotime('+1 year')); 
    }

    update_user_meta($user_id, 'points_expiration_date', $expiration_date);
}

function handle_sunnbucks_balance_expiration() {
    $users = get_users();

    foreach ($users as $user) {
        $user_id = $user->ID;

        set_expiration_date($user_id);
    }
}

add_action('user_register', 'set_expiration_date');
add_action('profile_update', 'set_expiration_date');







// CODE FROM FUCNTIONS.PHP 


function add_custom_role() {
	$customer_role = get_role('customer');
	$customer_capabilities = $customer_role->capabilities;
	$customer_capabilities['custom_capability'] = true; 
	add_role('dealer', __('Dealer', 'woocommerce'), $customer_capabilities);
}

add_action('init', 'add_custom_role');

function redirect_non_logged_in_users() {
	if (!is_user_logged_in()) {
			if (!is_page('login') && !is_page('register')) {
					wp_redirect(wp_login_url());
					exit;
			}
	}
}

add_action('template_redirect', 'redirect_non_logged_in_users');
function add_registration_link() {
	if (!is_user_logged_in()) {
			echo '<p class="register-link" style="
			p.register-link {
			margin-top: 10px;
			font-size: 17px;
			padding-bottom: 10px;
	};
	">You  have account ? <a class="login-btn" href="' . esc_url(wp_login_url()) . '">Login</a></p>';
	}
}

add_action('login_form', 'add_registration_link');
add_action('register_form', 'add_registration_link');



function via_limit_purchase_for_product($valid, $product_id, $quantity) {
   
    if ($product_id == 1566) {
        $product = wc_get_product($product_id);
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();

          
            $previous_purchase = wc_customer_bought_product($user_id, get_current_user_id(), 1566);

            if ($previous_purchase) {
              
                wc_add_notice(__('You can only purchase Product <b>'.esc_html($product->get_name()).'</b> once.', 'your-text-domain'), 'error');
                $valid = false;
            }
        } else {
          
            if (isset($_COOKIE['product_1566_purchased']) && $_COOKIE['product_1566_purchased'] == 'yes') {
                wc_add_notice(__('You can only purchase Product <b>'.esc_html($product->get_name()).'</b> once.', 'your-text-domain'), 'error');
                $valid = false;
            }
        }
    }

    return $valid;
}

add_filter('woocommerce_add_to_cart_validation', 'via_limit_purchase_for_product', 10, 3);



// Function to display text on product page if conditions are true
function display_text_on_product_page() {
    global $product;

    $product_id = $product->get_id();

    $points_price_logo = get_post_meta($product_id, '_points_price_for_logo', true);
    $min_quantity_logo = get_post_meta($product_id, '_min_quantity_for_logo', true);

    if ($points_price_logo && $min_quantity_logo) {
        ?>
        <div class="product_texte_logo">
            <p>Starting cost for adding your own logo: <span class="fee_logo">45$ or 58.50 Points.</span><br/>
           A minimum order of 5 is required to enable the <span class="box_logo">ADD YOUR LOGO box.</span></p>
        </div>
        <style>
            .product_texte_logo {
            width: 100%;
             height: auto;
            
            background: #fcc00f;
            padding: 28px 5px 1px 10px;
            color: black;
            font-weight: 700;
        }
        .product_texte_logo span.fee_logo {
            text-decoration: underline;
            color: #494949;
        }
        .product_texte_logo span.box_logo {
      
            color: #494949;
        }
        </style>
        <?php
       
             

       
    }
}

// Hook the function to display on the product page
add_action('woocommerce_before_variations_form', 'display_text_on_product_page', 6);


// Change cart item price
add_action( 'woocommerce_before_calculate_totals', 'category_ferns_set_bulk_discount', 20, 1 );
function category_ferns_set_bulk_discount( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) )
        return;

    if ( did_action('woocommerce_before_calculate_totals') > 1 )
        return;


        foreach($cart->get_cart() as $cart_item) {
             $product = $cart_item['data'];
        $quantity = $cart_item['quantity'];
        $price_logo_string = $cart_item['pricesssssss'][1];
        preg_match_all('!\d+!', $price_logo_string, $price_logo);
        $logo_price_total = floatval($price_logo[0][1]) * $quantity ;
      
        if ($product->is_type('variable')) {
            
            $variation_id = $cart_item['variation_id'];
            $variation = new WC_Product_Variation($variation_id);
            $regular_price = floatval($variation->get_price());
             
        } else {
            $regular_price = floatval($product->get_price());
        }
        $cart_item['data']->set_price( $regular_price);
        

    }
}
