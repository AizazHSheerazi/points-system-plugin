<?php
// 'payment-points' => __( 'Points', 'woocommerce' ),
function via_add_points_support_endpoint() {
    add_rewrite_endpoint( 'payment-points', EP_ROOT | EP_PAGES );
}
  
add_action( 'init', 'via_add_points_support_endpoint' );
  

  
function via_points_query_vars( $vars ) {
    $vars[] = 'payment-points';
    return $vars;
}
  
add_filter( 'query_vars', 'via_points_query_vars', 0 );

  
function via_add_points_link_my_account( $items ) {
    $items['payment-points'] = 'Points';
    return $items;
}
  
add_filter( 'woocommerce_account_menu_items', 'via_add_points_link_my_account' );

  
function via_add_points_content() {
  $user_id = get_current_user_id();
  $points_balance =  get_user_meta($user_id, 'points', true);
  $points_spent = get_user_meta( $user_id, 'points_spent',  true);
  $orders = wc_get_orders( array(
    'customer' => $user_id,
  ) ); 

  if (empty($points_spent)) {
    $points_spent = 'Not Yet!';
  }
  $orders = wc_get_orders(array(
    'customer' => $user_id,
    'payment_method' => 'points',
));
  ?>
     <div class="points_dash">
    <h3 >Points</h3>
    <div class="points_dash_content">
    <div class="points_dash_content_card">
      <div class="card points_card">
        <h4>Total Points Balance</h4>
        <p><?php echo  esc_html( $points_balance ) ?><span>$</span></p>
      </div>

      <div class="card points_spent_card">
        <h4>Total Points Spent</h4>
        <p><?php echo  esc_html( $points_spent ) ?><span>$</span></p>
      </div>
    </div>
    <h3>Products bought with Points</h3>
    <div class="table-responsive">
    <table class="table table-bordered">
            <thead>
            <tr>
                <th>Order ID</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price (Points)</th>
                <th>Purchase Date</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>

            <?php foreach ($orders as $order) : ?>
    <?php foreach ($order->get_items() as $item) : ?>
        <?php
        $product = $item->get_product();
        $purchase_date = $order->get_date_created()->format('Y-m-d');
        $status = $order->get_status();
        ?>
        <tr>
            <td><?php echo esc_html($order->get_id()); ?></td>
           
            <td> <?php
                            $product_url = get_permalink($product->get_id());
                            echo '<a href="' . esc_url($product_url) . '">' . esc_html($item->get_name()) . '</a>';
                            ?></td>
            <td><?php echo esc_html($item->get_quantity()); ?></td>
            <td><?php echo esc_html($item->get_total()); ?></td>
            <td><?php echo esc_html($purchase_date); ?></td>
            <td><?php echo esc_html($status); ?></td>
        </tr>
    <?php endforeach; ?>
<?php endforeach; ?>


            </tbody>
        </table>
        </div>
        </div>
    </div>
</div>
<style>
  

    .points_dash {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }

    .points_dash_content_card {
    display: flex;
}
    .points_dash_content .card {
      background-color: #ffffff;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin: 20px;
      text-align: center;
    }

    @media (min-width: 768px) {
      .points_dash_content .card {
        width: calc(50% - 40px);
      }
    }


  </style>
  <?php
}
  
add_action( 'woocommerce_account_payment-points_endpoint', 'via_add_points_content' );
