<?php
// if (!defined('ABSPATH')) {
//     exit;
// }
// require_once WP_PLUGIN_DIR . '/woocommerce/includes/wc-conditional-functions.php';

// add_filter( 'woocommerce_payment_gateways', array($this,'abt_object_payment') );
// public function abt_object_payment( $methods) {
//     $methods[] = 'Advance_Bank_Transfer_class';
//     return $methods;
// }
// if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {

//   $wc_gateways      = new WC_Payment_Gateways();

  
//             $available_gateways = $wc_gateways->get_available_payment_gateways();

//             foreach ($available_gateways as $gateway) {
//                 if ($gateway->id === 'points') {
//                     echo '<div class="points-gateway-select">';
//                     echo '<span class="points-text">Pay with Points</span>';
//                     echo '<input type="radio" name="payment_method" value="' . esc_attr($gateway->id) . '" id="payment_method_' . esc_attr($gateway->id) . '" class="input-radio points-radio" checked="checked">';
//                     echo '</div>';
//                 }
            
//         } 
   
// } else {
//     echo 'WooCommerce is not active.';
// }
