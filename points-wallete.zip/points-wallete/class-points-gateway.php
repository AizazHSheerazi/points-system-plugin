<?php
if (!defined('ABSPATH')) {
    exit;
}
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
    return;
}




add_action( 'plugins_loaded', 'points_init_gateway_class' );
function points_init_gateway_class(){
    class WC_Points_Gateway extends WC_Payment_Gateway  {

        public function __construct() {
            $this->id                 = 'points_payment_gateway';
            $this->method_title       = __('Points Payment Gateway', 'your-text-domain');
            $this->method_description = __('Pay securely using your Points balance.', 'your-text-domain');
            $this->title              = $this->get_option('title');
            $this->description        = $this->get_option('description');
            $this->icon               = ''; 
            $this->has_fields         = true;
            $this->init_form_fields();
            $this->init_settings();

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => __('Enable/Disable', 'your-text-domain'),
                    'type'    => 'checkbox',
                    'label'   => __('Enable Points Payment Gateway', 'your-text-domain'),
                    'default' => 'no',
                ),
                'title' => array(
                    'title'       => __('Title', 'your-text-domain'),
                    'type'        => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'your-text-domain'),
                    'default'     => __('Pay with Points', 'your-text-domain'),
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => __('Description', 'your-text-domain'),
                    'type'        => 'textarea',
                    'description' => __('This controls the description which the user sees during checkout.', 'your-text-domain'),
                    'default'     => __('Pay securely using your Points balance.', 'your-text-domain'),
                ),
            );
        }

        public function process_payment($order_id) {
            $sunbuck_subtotal = 0;
            $cartData_var = WC()->cart->get_cart();
        
             foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
        $product_id = $cart_item['product_id'];
          $points_price_logo = get_post_meta($product_id, '_points_price_for_logo', true);
         $min_quantity_logo = get_post_meta($product_id, '_min_quantity_for_logo', true);
        $variation_id = $cart_item['variation_id'];

       
        $sunbuck_price = get_post_meta($variation_id > 0 ? $variation_id : $product_id, '_points_price', true);
        $quantity = $cart_item['quantity'];
        $total_price_points = $points_price_logo * $quantity;

         
        if (!empty($sunbuck_price) ) {
            if(!empty($points_price_logo)){
                  $product_total_sunbuck_price = $sunbuck_price * $quantity;
                  $logo_product_points = $points_price_logo * $quantity;
                  
                 $sunbuck_subtotal +=  $product_total_sunbuck_price +  $logo_product_points;
                
              }else{
                 $sunbuck_subtotal += $sunbuck_price * $quantity;
              
            }
           
        }
    }

            $order = wc_get_order($order_id);

            $user_id = get_current_user_id();
            $user_points = get_user_meta($user_id, 'points', true);

            if ($user_points >= $sunbuck_subtotal) {
                $user_points -= $sunbuck_subtotal;
                $points_spent += $sunbuck_subtotal;
                $order->set_total($sunbuck_subtotal);
                // $order->set_subtotal($sunbuck_subtotal);
                update_user_meta($user_id, 'points', $user_points);
                update_user_meta( $user_id, 'points_spent',  $points_spent );

                
                $order->update_status('processing', __('Payment processed with Points.', 'your-text-domain'));
                $order->reduce_order_stock();
                WC()->cart->empty_cart();

                return array(
                    'result'   => 'success',
                    'redirect' => $this->get_return_url($order),
                );
            } else {
                wc_add_notice(__('Insufficient Points balance. Please choose another payment method.', 'your-text-domain'), 'error');
                return;
            }
        }
    }
}

add_filter('woocommerce_payment_gateways', 'add_points_gateway_class');

 function add_points_gateway_class($methods) {
     $methods[] = 'Points_Gateway';
     return $methods;
 }
 add_filter( 'woocommerce_payment_gateways', 'points_add_gateway_class' );
 function points_add_gateway_class( $gateways ) {
     $gateways[] = 'WC_Points_Gateway';
     return $gateways;
 }
