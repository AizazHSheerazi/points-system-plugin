<?php
/**
 * Points Elementor Widget
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Points_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'points_widget';
    }

    public function get_title() {
        return __('Points Widget', 'your-text-domain');
    }

    public function get_icon() {
        return 'eicon-ticker';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function _register_controls() {
       
    }

    protected function render() {
      $user_id = get_current_user_id();
      $points = get_user_meta($user_id, 'points', true);
  
      if (!$points) {
          $points = 0;
      }
  
      $assets_url = plugins_url('assets', __FILE__);
  
      $svg_filename = 'wallet-48.png';
      $svg_attributes = 'width=16px height=16px'; 
  
      $icon_html = sprintf(
          '<img src="%s/%s" alt="Points Icon" %s>',
          esc_url($assets_url),
          esc_attr($svg_filename),
          esc_attr($svg_attributes)
      );
      if (is_user_logged_in()) {
        echo '<div class="points-container">' . $icon_html . '<span class="points-value" style="color: white;margin-left: 5px;">Points: ' . $points . '</span></div>';
      }
  }
  
}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type(new Points_Widget());
